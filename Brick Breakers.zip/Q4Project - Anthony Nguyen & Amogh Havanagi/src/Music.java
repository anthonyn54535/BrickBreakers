


import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Music  implements Runnable  {
	Thread t;
	File audioFile ;
    AudioInputStream audioStream;
    Clip audioClip;
    String fn;
    //constructor that takes in file and also boolean to see if it should loop or not
	public Music(String fileName, boolean loops) {
		fn = fileName;
		audioFile = new File(fileName);
		try {
			audioStream = AudioSystem.getAudioInputStream(audioFile); // gets audio stream from the file
			AudioFormat format = audioStream.getFormat();
	        DataLine.Info info = new DataLine.Info(Clip.class, format);
	        audioClip = (Clip) AudioSystem.getLine(info);
	        
	        if(loops) {
	        	audioClip.loop(audioClip.LOOP_CONTINUOUSLY);;
	        }	        
	        audioClip.open(audioStream);
	        //audioClip.start();
		} catch (UnsupportedAudioFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void play() {
		start3();
	}
	// helper to create and start a thread
	public void start3() {
	     t = new Thread (this, fn);
	     start2();
	     t.start ();
	}
	//another helper
	public void start() {
	     t = new Thread (this, fn);
	     t.start ();
	}
	//initalize and start playing
	public void start2() {
		audioFile = new File(fn);
		try {
			audioStream = AudioSystem.getAudioInputStream(audioFile);
			AudioFormat format = audioStream.getFormat();
	        DataLine.Info info = new DataLine.Info(Clip.class, format);
	        audioClip = (Clip) AudioSystem.getLine(info);
	        audioClip.open(audioStream);
	        audioClip.start();
		} catch (UnsupportedAudioFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		 audioClip.start();
	}
	

}
